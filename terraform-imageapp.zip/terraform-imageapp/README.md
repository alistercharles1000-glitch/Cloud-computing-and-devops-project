# Image App — Scripted Infrastructure as Code (Part I)

## Description

This repository defines the cloud infrastructure for a web application that stores and displays images. Users can upload image files through a web form, which are saved to an Azure Blob Storage container. A second page lists all uploaded files and provides a download link for each.

All infrastructure is defined as code using Terraform, targeting Microsoft Azure. No resources are created manually through the Azure Portal.

---

## Approach

**Cloud Provider:** Microsoft Azure (Azure for Students subscription)

**Tool:** Terraform v1.3+ with the `azurerm` provider (~> 3.0)

**Design principles:**
- Keep it simple — four resources cover all requirements for both Part I and Part II
- Avoid hardcoded secrets — the storage connection string lives in Key Vault, not in code or environment variables
- Use a managed identity so the app authenticates to Key Vault without any passwords
- Use the Free (F1) App Service tier to stay within student subscription limits

**Resource naming convention:** All resources use the pattern `<type>-<project>-<environment>`, e.g. `rg-imageapp-dev`. The storage account omits hyphens because Azure does not allow them in storage account names.

---

## Connections Between Resources

```
Browser
  └──► App Service (app-imageapp-dev)
          ├── reads KEY_VAULT_URL env variable
          ├──► Key Vault (kv-imageapp-dev)
          │       └── returns StorageConnectionString secret
          └──► Storage Account (stimageappdev)
                  └── images container (list blobs, upload blobs)
```

1. The browser makes HTTP requests to the App Service public URL.
2. The App Service reads `KEY_VAULT_URL` from its application settings (set by Terraform).
3. At startup, the app fetches the `StorageConnectionString` secret from Key Vault using the Azure SDK.
4. The app uses that connection string to list and upload blobs in the `images` container.

---

## Authentication / Identity Context

| Who | Authenticates as | To access |
|-----|-----------------|-----------|
| Developer (terraform apply) | Azure CLI logged-in account | Key Vault (full secret permissions) |
| App Service | System-assigned Managed Identity | Key Vault (Get, List secrets only) |
| App Service | Storage connection string (retrieved from Key Vault) | Storage Account blobs |

**Managed Identity** is the key security pattern here. Azure automatically creates an identity for the App Service and injects a credential into the runtime environment. The app calls `DefaultAzureCredential()` from the Azure SDK — no usernames, passwords, or API keys appear anywhere in the code or Terraform files.

The access policy for the App Service grants only `Get` and `List` on secrets (principle of least privilege). It cannot create or delete secrets.

---

## Repository Structure

```
terraform-imageapp/
├── provider.tf      # Terraform version + Azure provider configuration
├── variables.tf     # Input variables (location, project name, environment)
├── main.tf          # All Azure resource definitions
├── outputs.tf       # Exported values (URLs, names) after apply
└── README.md        # This file
```

---

## How to Deploy

### Prerequisites
- [Terraform](https://developer.hashicorp.com/terraform/install) installed
- [Azure CLI](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli) installed
- An active Azure for Students subscription

### Steps

```bash
# 1. Log in to Azure
az login

# 2. Clone the repository
git clone <your-repo-url>
cd terraform-imageapp

# 3. Initialise Terraform (downloads the Azure provider)
terraform init

# 4. Preview what will be created
terraform plan

# 5. Deploy the infrastructure
terraform apply

# 6. When finished, destroy all resources to avoid charges
terraform destroy
```

After `terraform apply` completes, the outputs will show your App Service URL, storage account name, and Key Vault URL.

---

## Terraform Resource Summary

| Resource | Type | Purpose |
|----------|------|---------|
| `azurerm_resource_group.rg` | Resource Group | Container for all project resources |
| `azurerm_storage_account.storage` | Storage Account | Stores uploaded image files |
| `azurerm_storage_container.images` | Blob Container | Public-readable container named `images` |
| `azurerm_key_vault.kv` | Key Vault | Securely stores the storage connection string |
| `azurerm_key_vault_secret.storage_connection` | KV Secret | The actual connection string value |
| `azurerm_key_vault_access_policy.deployer` | KV Access Policy | Grants the deploying account full secret access |
| `azurerm_key_vault_access_policy.app_service` | KV Access Policy | Grants the App Service read-only secret access |
| `azurerm_service_plan.plan` | App Service Plan | Compute plan (Linux, Free F1 tier) |
| `azurerm_linux_web_app.app` | App Service | Hosts the Python web application |
